<!DOCTYPE html>
<html lang="en">
  <head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>EXER4</title>
  </head>
  <body>
      
      <?php
      
      /*
        In this PHP exercise, you will put all the loops through their paces. Write a script that will print the following to the browser:

        abc abc abc abc abc abc abc abc abc

        xyz xyz xyz xyz xyz xyz xyz xyz xyz

        1 2 3 4 5 6 7 8 9

        1.Item A
        2.Item B
        3.Item C
        4.Item D
        5.Item E
        6.Item F

        Create the 'abc' row with a while loop, the 'xyz' row with a do-while loop, and the last two sections with for loops. Remember to include HTML and source code line breaks in your output. No arrays allowed in this solution.
      */
      
      
        $o=1;
        while ($o<10) {//Con el bucle while hacemos que se repita abc hasta 9 veces y cuando llegue a ellas se salga del bucle
          echo "abc ";
          $o++;
        }
        //saltar linea.
        echo "<br/><br/>";
        //Igual que el ejercicio anterior pero con bucle do-while
        $i = 0;
        do {
            echo "xyz ";
            $i++;
        } while ($i < 9);
        echo "<br/><br/>";
        //Ahora hacemos el bucle for que cuente del 1 al 9 y se salga cuando llegue a 9
        for ($i = 1; $i <= 9; $i++) {
          echo "$i ";
        }
        echo "<br/>";
        //Creamos la lista ordenada.
        echo "<ol>";
        //Con el bucle for ponemos el numero de items que vamos a utilizar.
        for ($i = 1; $i <= 6; $i++) {

          echo "<li>";//Comienza el item
          
          switch ($i) {// Un switch para dependiendo el numero que nos saque el for nos ponga una letra de item determinado por cada case.
            case 1:
                echo "Item A";
                break;
            case 2:
                echo "Item B";
                break;
            case 3:
                echo "Item C";
                break;
            case 4:
                echo "Item D";
                break;
            case 5:
                echo "Item E";
                break;
            case 6:
                echo "Item F";
                break;
              }
          
          echo "</li>";//Cerramos los items.
        }
        
        echo "</ol>";//Cerramos la lista ordenada.
      ?>
  </body>
</html>