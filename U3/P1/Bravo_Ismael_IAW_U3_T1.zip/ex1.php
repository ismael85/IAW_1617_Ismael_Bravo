<!DOCTYPE html>
<html lang="en">
  <head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>EXER1</title>
  </head>
  <body>
      
      <?php
       /*
      Write a script to reproduce the output below.

      Manipulate only one variable using no simple arithmetic operators
      to produce the values given in the statements.

      Hint: In the script each statement ends with "Value is now $variable."

      Value is now 8.
      Add 2. Value is now 10.
      Subtract 4. Value is now 6.
      Multiply by 5. Value is now 30.
      Divide by 3. Value is now 10.
      Increment value by one. Value is now 11.
      Decrement value by one. Value is now 10.

      */
      //Vamos cambiando a la variable var el valor que pide el ejercicio.
      //Ponemos a cada variable la operación que vaya a realizar sobre la propia variable
      //+ suma a la variable la cantidad asociada, -restar a la variable la cantidad asociada
      //* multiplica a la variable la cantidad asociada, / divide a la variable la cantidad asociada
      
      $var=8;
      echo "Value is now $var.<br/>";
      $var=$var+2;
      echo "Add 2. Value is now $var. <br/>";
      $var=$var-4;
      echo "Subtract 4. Value is now $var. <br/>";
      $var=$var*5;
      echo "Multiply by 5. Value is now $var. <br/>";
      $var=$var/3;
      echo "Divide by 3. Value is now $var. <br/>";
       $var=$var+1;
       echo "Increment value by one. Value is now $var.<br/>";
       $var=$var-1;
      echo "Decrement value by one. Value is now $var.";
      
      ?>
  </body>
</html>