<!DOCTYPE html>
<html lang="en">
  <head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>EXER2</title>
  </head>
  <body>
      
      <?php
      
      /*
      When you are writing scripts, you will often need to see exactly
      what is inside your variables.

      For this PHP exercise, think of the ways you can do that,
      then write a script that outputs the following, using the echo statement only for line breaks.
      */
      
      $tipo='Harry';
      $num=28;
      var_dump($tipo);//Utilizamos var_dump para sacar el tipo de dato de la variable + su contenido
      echo "<br/>";//Se pone echo mas br para saltar de linea
      print_r($tipo);//Con prin_r() solo sacaremos el valor de la variable.
      echo "<br/>";
      var_dump($num);
      echo "<br/>";
      $tipo=null;//Decimos que el dato esta vacio y con el var_dump nos saca su tipo de dato que en este caso en nulo
      var_dump($tipo);
     
          
       
      ?>
  </body>
</html>