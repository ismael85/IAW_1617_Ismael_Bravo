<!DOCTYPE html>
<html lang="en">
  <head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>EXER3</title>
  </head>
  <body>
      
      <?php
      
      /*
      Write a script that gets the current month and prints one of the following responses, depending on whether it's August or not:

        It's August, so it's really hot.
        Not August, so at least not in the peak of the heat.

        Note: Use date() function.
      */
      
      date_default_timezone_set('europe/madrid');//Ponemos la zona horaria en que nos encontramos
      $mes = date("month");//Establecemos en la variable el nombre del mes
      
      if ($mes == 'August') {//Ponemos como condición que si el mes no es agosto que ponga la frase del echo
        echo "It's August, so it's really hot.";
      } else {// Si no cumple la condición anterior que muestre la otra frase
        echo "Not August, so at least not in the peak of the heat.";
      }
 
      ?>
  </body>
</html>