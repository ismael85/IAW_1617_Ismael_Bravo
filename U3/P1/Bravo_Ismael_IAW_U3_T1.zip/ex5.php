<!DOCTYPE html>
<html lang="en">
  <head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>EXER5</title>
  </head>
  <body>
      
      <?php
      /*
    Create a 10 x 10 table where the background color is gray for even rows and
    red for odd rows. The cells' dimensions must be 50x50
    */
    
    $i = 1;//Variable para crear una fila en un bucle.
    
    $celda = 1;//Variable para el contenido de las celdas, su numero empezará por 1.
    
    $tam = 10;//Tamaño de la tabla, si la variable=10, tabla 10*10
    
    echo "<table border='1px solid black'>";//Creamos la tabla y le ponemos un borde.
    //Aqui creamos las filas.
    while ($i<=$tam) {
      //Variable para crear las celdas en un bucle.
      $o = 1;
      //El comienzo de la fila.
      echo "<tr ";
      //Ponemos que si la fila sea impar, sera de color gris, si es par, rojo.
      //Y cerramos el tr, quedando <tr bgcolor='x'>.
      if ($i % 2 == 0) {//Si el resto de 2 es 0 es que es par y lo tanto color gris
        echo "bgcolor='grey'>";
      } else {
        echo "bgcolor='red'>";
      }
      //Ahora toca un bucle para insertar las celdas. $o es la posicion.
      //$tam la cantidad que queremos (5).
      while ($o<=$tam) {
        echo "<td width='50px' height='50px' align='center'>$celda</td>";//Creamos la celda, con tamaño 50x50px, alineado en el centro.
        $o++;//Aumentamos la posicion de la celda hasta cerrar el while.
        $celda++;//Aumentamos el valor que estará dentro de cada celda segun su posicion.
      }
      echo "</tr>";//Cerramos la fila
      $i++;//Aumentamos el valor de la fila hasta que se salga del while.
      }
      
     echo "</table>";//Cierre de la tabla.
      
        ?>
  </body>
</html>