--
-- MySQL 5.5.5
-- Mon, 26 Sep 2016 16:32:43 +0000
--

CREATE DATABASE `taller` DEFAULT CHARSET latin1;

USE `taller`;

CREATE TABLE `clientes` (
   `codcli` varchar(50) not null,
   `nif` varchar(10),
   `nombre` varchar(50),
   PRIMARY KEY (`codcli`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

INSERT INTO `clientes` (`codcli`, `nif`, `nombre`) VALUES 
('1', '11', 'juan'),
('2', '22', 'rosa'),
('3', '33', 'jaime'),
('4', '44', 'jose'),
('5', '55', 'nerea');

CREATE TABLE `coches` (
   `matricula` varchar(10) not null,
   `codcli` varchar(50),
   PRIMARY KEY (`matricula`),
   KEY `codcli` (`codcli`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

INSERT INTO `coches` (`matricula`, `codcli`) VALUES 
('11', '1'),
('22', '2'),
('33', '3'),
('44', '4'),
('55', '5');

CREATE TABLE `revisiones` (
   `codrev` varchar(50) not null,
   `matricula` varchar(10),
   PRIMARY KEY (`codrev`),
   KEY `matricula` (`matricula`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

INSERT INTO `revisiones` (`codrev`, `matricula`) VALUES 
('111', '11'),
('222', '22'),
('333', '33'),
('444', '44'),
('555', '55');